
package basededatos;

import vista.Datos;
import controlador.Control;

public class BaseDatos {


    public static void main(String[] args) {
        Datos datos = new Datos();
        Control control = new Control(datos);
        control.iniciarPrograma();
        
    }
    
}
