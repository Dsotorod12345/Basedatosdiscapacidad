package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.JOptionPane;
import vista.Datos;

public class Control implements ActionListener {

    Datos datos;

    public Control(Datos datos) {
        this.datos = datos;
        this.datos.jButtonBuscar.addActionListener(this);
        this.datos.jButtonRegistrar.addActionListener(this);
    }

    public void iniciarPrograma() {
        datos.setTitle("Registro de Personas");
        datos.setLocationRelativeTo(null);
        datos.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent oprimir) {

        if (datos.jButtonRegistrar == oprimir.getSource()) {
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/bd_discapacidad", "root", "");
                PreparedStatement prep = con.prepareStatement("insert into regdisca values(?,?,?,?)");
                prep.setString(1, "0");
                prep.setString(2, datos.jTextFieldNombre.getText().trim());
                prep.setString(3, datos.jTextFieldDiscapacidad.getText().trim());
                prep.setString(4, datos.jTextFieldEdad.getText().trim());
                prep.executeUpdate();

                datos.jTextFieldNombre.setText("");
                datos.jTextFieldDiscapacidad.setText("");
                datos.jTextFieldEdad.setText("");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error de Registro!!!"+"\n"+e);
            } finally {
                JOptionPane.showMessageDialog(null, "Registro exitoso!!!");
            }
        }

        if (datos.jButtonBuscar == oprimir.getSource()) {
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/bd_discapacidad", "root", "");
                PreparedStatement prep = con.prepareStatement("select * from regdisca where Id = ?");
                prep.setString(1, datos.jTextFieldCodigo.getText().trim());
                ResultSet resul = prep.executeQuery();
                
                if(resul.next()){
                    datos.jTextFieldNombre.setText(resul.getString("Nombre"));
                    datos.jTextFieldDiscapacidad.setText(resul.getString("Tipo de Discapacidad"));
                    datos.jTextFieldEdad.setText(resul.getString("Edad"));
                }else{
                    JOptionPane.showMessageDialog(null, "Persona no Registrada!!!");
                }
                datos.jTextFieldCodigo.setText("");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error de Registro!!!"+"\n"+e);
            }
        }
    }

}
